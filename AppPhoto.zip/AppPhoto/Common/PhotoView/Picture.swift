//
//  Photo.swift
//  Hopplers
//
//  Created by Nikita Rosenberg on 02/06/2017.
//  Copyright © 2017 Magora Systems. All rights reserved.
//

import UIKit


class Picture{
    var raw: UIImage?
    var url: URL?
}
