//
//  PhotosView.swift
//  Hopplers
//
//  Created by Nikita Rosenberg on 02/06/2017.
//  Copyright © 2017 Magora Systems. All rights reserved.
//

import UIKit
import SnapKit





class PhotosView: UIView,
UICollectionViewDelegate,
UICollectionViewDataSource,
UICollectionViewDelegateFlowLayout {
    
    
    
    
    //MARK: - Outlets
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    //MARK: - Properties
    var data = [Picture]() {
        didSet {
            populateView()
        }
    }
    
    
    
    ///MARK: - Lifecycle
    //MARK: - So hard apple initizlization from UI
    private var view: UIView!
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }
    
    func xibSetup() {
        let viewName = "PhotosView"
        guard let view = Bundle.main.loadNibNamed(viewName, owner: self, options: nil)?.first as? UIView else {
            assertionFailure("\(viewName) not loaded")
            return
        }
        self.view = view
        
        self.view.frame = self.bounds
        self.view.clipsToBounds = true
        self.addSubview(view)
        self.view.translatesAutoresizingMaskIntoConstraints = false;
        
        self.snp.makeConstraints { (make) in
            make.edges.equalTo(view).inset(UIEdgeInsetsMake(0, 0, 0, 0))
        }
        
        
        self.collection.delegate = self
        self.collection.dataSource = self
        
      //  self.collection.register(PhotoCell.self, forCellWithReuseIdentifier: "\(PhotoCell.self)")
        self.collection.register(UINib(nibName: "\(PhotoCell.self)", bundle: nil), forCellWithReuseIdentifier: "\(PhotoCell.self)")
    }
    
    
    func populateView() {
        self.collection.collectionViewLayout.invalidateLayout()
        self.collection.reloadData()
        self.pageControl.numberOfPages = self.data.count
        self.currentPhoto = self.data.count > 0 ? 0 : nil
        self.scroll(toPhoto: self.currentPhoto)
    }
    
    
    
    
    //MARK: - Collection View
    var currentPhoto: Int? {
        get {
            return self.pageControl.currentPage
        }
        set {
            guard let newValueGuard = newValue else {
                return
            }
            self.pageControl.currentPage = newValueGuard
        }
    }
    
    func scroll(toPhoto index: Int?) {
        guard let newValueGuard = index else {
            return
        }
        
        let rect = CGRect(x: self.collection.frame.width * CGFloat(newValueGuard), y: 0, width: self.collection.frame.width, height: self.collection.frame.height)
        self.collection.scrollRectToVisible(rect, animated: false)
    }
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.data.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "\(PhotoCell.self)", for: indexPath) as! PhotoCell
        cell.data = self.data[indexPath.row]
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.currentPhoto = Int(self.collection.contentOffset.x / self.collection.frame.width)
    }
}
