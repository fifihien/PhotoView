//
//  PhotoCell.swift
//  Hopplers
//
//  Created by Nikita Rosenberg on 02/06/2017.
//  Copyright © 2017 Magora Systems. All rights reserved.
//

import UIKit
import AlamofireImage


class PhotoCell: UICollectionViewCell {
    
    
    //MARK: - Outlets
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    var data: Picture! {
        didSet {
            populateView()
        }
    }
    
    

    
    //MARK: - Lifecycle
    func populateView() {
        if let raw = data.raw {
            self.imageView.image = raw
        }
        else if let url = data.url {
            self.imageView.loadFromWithURL(url: url, noImage: UIImage(named: "bgNoImage" )!)
            //self.imageView.af_setImage(withURL: url)
        }
        else {
            self.imageView.image = nil
        }
        
    }
    
    
    
    
}
