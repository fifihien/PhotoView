//
//  CommonExtension.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import UIKit
import AlamofireImage
extension UIImageView {
    
    public func loadFromUrl(url: String?, noImage: UIImage){
        if let avatarUrl = url {
            if let imgURL = NSURL(string: avatarUrl) {
                
                af_setImage(withURL: imgURL as URL, placeholderImage:UIImage(named:"loadIcon"), filter: nil, progress:nil,completion:nil)
                
            } else {
                self.image = noImage
            }
        } else {
            self.image = noImage
        }
    }
    
    public func loadFromWithURL(url: URL?, noImage: UIImage){
        if let avatarUrl = url {
            af_setImage(withURL: avatarUrl , placeholderImage:UIImage(named:"loadIcon"), filter: nil, progress:nil,completion:nil)
        } else {
            self.image = noImage
        }
    }
    
    func changeImageColor(color : UIColor) {
        let imageTmp = self.image
        self.image = image?.withRenderingMode(.alwaysTemplate)
        self.tintColor = color
    }
    
}
