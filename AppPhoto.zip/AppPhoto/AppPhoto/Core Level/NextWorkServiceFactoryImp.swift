//
//  NextWorkServiceFactoryImp.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

class NetworkServiceFactoryImp: NetworkServiceFactory {
    
    func makeMainNetworkDispatcher() -> NetworkDispatcher {
        let environment = RakutenNetworkEnvironment(userSessionManager: ApplicationFactoryImp.sharedFactory.makeSessionManager())
        return MainNetworkDispatcherImpl(environment: environment)
    }
    
}
