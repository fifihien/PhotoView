//
//  KeyValueStorage.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

protocol KeyValueStorage {
    
    func setValue(value: Any?, forKey: String)
    func getValue(forKey: String) -> Any?
    
}
