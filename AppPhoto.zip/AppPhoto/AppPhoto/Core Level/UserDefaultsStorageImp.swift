//
//  UserDefaultsStorageImp.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

class UserDefaultsStorageImp: KeyValueStorage {
    
    func setValue(value: Any?, forKey: String) {
        UserDefaults.standard.set(value, forKey: forKey)
        UserDefaults.standard.synchronize()
    }
    
    func getValue(forKey: String) -> Any? {
        return UserDefaults.standard.value(forKey: forKey)
    }
    
}
