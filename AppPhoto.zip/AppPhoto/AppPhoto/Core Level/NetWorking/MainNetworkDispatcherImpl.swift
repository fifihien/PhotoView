//
//  MainNetworkDispatcherImpl.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//
import Foundation
import RxSwift
import Alamofire
import ObjectMapper
import AlamofireObjectMapper

class MainNetworkDispatcherImpl: NetworkDispatcher {
    
    private var environment : NetworkEnvironment
    private var sessionManager : SessionManager
    
    public required init(environment: NetworkEnvironment) {
        self.environment = environment
        let configuration = URLSessionConfiguration.default
        self.sessionManager = Alamofire.SessionManager(configuration: configuration)
    }
    
    public func execute<T:Mappable>(request: RequestModel, completionHandler: @escaping (Response<T>) -> Void) -> DataRequest {
        
        print("Headers: \(self.environment.headers)")
        
        let dataRequest = self.sessionManager.request(request.asURLRequest(environment: self.environment)!)
            .validate(statusCode: 200...499)
            .responseString(completionHandler: {(data : DataResponse<String>) in
                debugPrint(data)
            })
            .responseObject(completionHandler: { (data : DataResponse<T>) in
                
                switch data.result {
                case let .success(value):
                    completionHandler(.Success(value))
                    break
                case let .failure(error):
                    
                    completionHandler(.Error(error))
                    break
                }
            })
        print(dataRequest)
        return dataRequest
    }
    
}

