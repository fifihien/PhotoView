//
//  SessionStorage.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

protocol SessionStorage {
    var userSession: Session {get set}
}

extension UserDefaultsStorageImp: SessionStorage {
    
    var userSession: Session {
        get {
            
            var session = Session()
            session.accessToken = getValue(forKey: "accessToken") as? String
            session.refreshToken = getValue(forKey: "refreshToken") as? String
            session.userId = getValue(forKey: "userId") as? String
            session.accessTokenExpire = getValue(forKey: "accessTokenExpire") as? Date
            return session
        }
        
        set {
            setValue(value: newValue.accessToken, forKey: "accessToken")
            setValue(value: newValue.refreshToken, forKey: "refreshToken")
            setValue(value: newValue.accessTokenExpire, forKey: "accessTokenExpire")
            setValue(value: newValue.userId, forKey: "userId")
        }
    }
    
}
