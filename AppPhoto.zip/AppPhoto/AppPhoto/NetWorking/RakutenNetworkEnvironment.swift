//
//  HopplersNetworkEnvironment.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

class RakutenNetworkEnvironment: NetworkEnvironment {
    
    var name: String
    var host: String
    var cachePolicy: URLRequest.CachePolicy = .reloadIgnoringLocalAndRemoteCacheData
    var headers: [String : String] {
        return ["Accept" : "application/json"]
    }
    
    private var sessionManager: UserSessionManager
    init(userSessionManager: UserSessionManager) {
        self.sessionManager = userSessionManager
        self.name = "FlickrAPI"
        self.host = "https://api.flickr.com/services/rest/?method=flickr.photos.getRecent&api_key=fee10de350d1f31d5fec0eaf330d2dba&format=json&nojsoncallback=true"
        //self.host = "http://dev.hopplers.java.magora.team/api/v1"
    }

}
