//
//  ResponseModel.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

import Foundation
import Alamofire

public enum Response<T> {
    
    case Success(T)
    case Error(Error)
    
}
