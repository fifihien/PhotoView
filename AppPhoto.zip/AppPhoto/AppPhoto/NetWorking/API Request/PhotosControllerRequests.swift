//
//  PhotosControllerRequests.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import Alamofire

enum PhotoControllerRequests: RequestModel {
    
    case getPhotos(pageIndex: String ,cursor: String, pageSize: String)
    case getPhotoListPaging(atIndex: Int, sortKey: String, order: String ,cursor: String, pageSize: Int)
    
    public var path: String {
        switch self {
        case .getPhotos:
            return "&page=\(1)&per_page=\(5)"
        case let .getPhotoListPaging(atIndex,_,_,_,pageSize):
            return "&page=\(atIndex)&per_page=\(pageSize)"
        }
    }
    
    public var method: HTTPMethod {
        switch self {
        case .getPhotos:
            return .get
        case .getPhotoListPaging:
            return .get
        }
    }
    
    public var parameters: RequestParams {
        switch self {
        case let .getPhotos(searchKeyId, cursor, pageSize):
            
            return .url(["searchId": searchKeyId,"cursor": cursor, "pageSize": pageSize], encoding: URLEncoding())
            
        case let .getPhotoListPaging(atIndex,sortKey, order, cursor, pageSize):
            return .url(["atIndex": atIndex, "sort" : sortKey, "order" : order ,"cursor": cursor, "per_page": pageSize], encoding: URLEncoding())
            
        }
        
    }
    
    
}
