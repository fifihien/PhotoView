//
//  NetworkError.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import Alamofire

enum NetworkError: Error {
    
    enum ConnectionFailReasons {
        case noConnection
        case unknown
    }
    
    case unknown
    case connectionFail(reason: ConnectionFailReasons)
    case businessProblem(code: GlobalResponseCode, errors:[RestError]?)
    
}

extension NetworkError {
    
    public var errorMessage:String{
        
        if case let .businessProblem(code, errors) = self {
            
            if code.isSecurityError {
                if let errorMessage = errors?[0].message {
                    return errorMessage
                }
            }
            
            if errors != nil {
                if (errors?.count)! > 0 {
                    if let errorMessage = errors?[0].message {
                        return errorMessage
                    }
                }
            }
            
            return "Some things wrong?"
        }
        return "Some things wrong?"
    }
    
    public var isAccessTokenInvalid: Bool {
        
        if case let .businessProblem(code, errors) = self {
            
            if code.isSecurityError {
                
                if let errorCode = errors?[0].code {
                    
                    switch errorCode {
                    case .accessTokenInvalid:
                        return true
                    default:
                        return false
                    }
                }
            }
            
            return false
        }
        return false
        
    }
    
    public var isRefreshTokenInvalid: Bool {
        
        if case let .businessProblem(code, errors) = self {
            
            if code.isSecurityError {
                if let errorCode = errors?[0].code {
                    switch errorCode {
                    case .refreshTokenInvalid:
                        return true
                    default:
                        return false
                    }
                }
            }
            
            return false
        }
        return false
    }
    
}
