//
//  NetworkOperation.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import ObjectMapper
import RxSwift

class NetworkOperation<T: BaseResponse> {
    
    var request: RequestModel? {
        assertionFailure("Not implemnted request!")
        return nil
    }
    
    
    func execute(in dispatcher: NetworkDispatcher) -> Observable<T> {
        
        guard let request = self.request else {
            return Observable.empty()
        }
        
        return Observable<T>.create({ (observer) -> Disposable in
            let requestTask = dispatcher.execute(request: request, completionHandler: { (response : Response<T>) in
                
                switch response {
                case let .Success(data):
                    
                    guard let code = data.code else {
                        observer.onError(NetworkError.unknown)
                        return
                    }
                    
                    if code == .success {
                        observer.onNext(data)
                        observer.onCompleted()
                    } else {
                        observer.onError(NetworkError.businessProblem(code: code, errors: data.errors))
                    }
                    
                    break
                    
                case let .Error(error):
                    
                    switch (error as NSError).code {
                    case -1010 ... -1000:
                        observer.onError(NetworkError.connectionFail(reason: .noConnection))
                    default:
                        observer.onError(NetworkError.connectionFail(reason: .unknown))
                        break
                    }
                    break
                }
            })
            return Disposables.create {
                requestTask.cancel()
            }
            
        })
        
    }
}

