//
//  PhotoListOperations.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//
import Foundation
import RxSwift


class PhotoListOperations: NetworkOperation<ObjectResponse<PhotoDTO>> {
    
    let pageIndex: Int
    let cursor: String
    let pageSize: Int
    
    init(pageIndex: Int, cursor: String, pageSize: Int) {
        self.pageIndex = pageIndex
        self.cursor = cursor
        self.pageSize = pageSize
    }
    
    
    override var request: RequestModel? {
        
        return PhotoControllerRequests.getPhotoListPaging(atIndex: pageIndex, sortKey: "", order: "", cursor: cursor, pageSize: pageSize)

    }
    
    
    
}
