//
//  TripCell.swift
//  Hopplers
//
//  Created by Nikita Rosenberg on 02/06/2017.
//  Copyright © 2017 Magora Systems. All rights reserved.
//

import UIKit


class PhotoTableCell: UITableViewCell {
    
    //MARK: - Outlets
    @IBOutlet weak var dates: UILabel!
    
    @IBOutlet weak var timelineView: UIView!
    @IBOutlet weak var subcontentView: UIView!
    @IBOutlet weak var photosView: PhotosView!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var dayDot: UIImageView!
    @IBOutlet weak var sum: UILabel!
    @IBOutlet weak var likes: UILabel!
    @IBOutlet weak var views: UILabel!
    @IBOutlet weak var saved: UIButton!
    @IBOutlet weak var likedButton: UIButton!
    
    @IBOutlet weak var userImageContainer: UIView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userDates: UILabel!
    
    @IBOutlet weak var timelineFirstLine: UIView!
    @IBOutlet weak var timelineViewWidth: NSLayoutConstraint!
    @IBOutlet weak var datesTrailing: NSLayoutConstraint!
    @IBOutlet weak var datesHeight: NSLayoutConstraint!
    @IBOutlet weak var photosHeight: NSLayoutConstraint!
    
    //MARK: - Properties
    var isSavedTrip: Bool? {
        didSet {
            let saved = isSavedTrip != nil ? isSavedTrip! : false
            self.userImageContainer.isHidden = !saved
            self.userName.isHidden = !saved
            self.userDates.isHidden = !saved
            
            self.saved.setBackgroundImage(saved ? #imageLiteral(resourceName: "savedGreen") : #imageLiteral(resourceName: "saved"), for: .normal)
            self.day.isHidden = saved
            self.dayDot.superview?.isHidden = saved
        }
    }
    var data: ListPhotoItem? {
        didSet {
            populateView()
        }
    }
    
    var isFirstCellInTable: Bool {
        
        get {
            return self.timelineFirstLine.isHidden
        }
        set {
            self.timelineFirstLine.isHidden = newValue
        }
    }
    
    var isTimelineHidden: Bool {
        
        get {
            return self.timelineView.isHidden
        }
        set {
            self.timelineView.isHidden = newValue
            self.timelineViewWidth.constant = self.timelineView.isHidden ? self.datesTrailing.constant : 33
        }
    }
    
    var isDatesHidden: Bool {
        
        get {
            return self.dates.isHidden
        }
        set {
            self.dates.isHidden = newValue
            self.datesHeight.constant = self.dates.isHidden ? 0 : 23
        }
    }
    
    func setHomeMode() {
        
        self.isDatesHidden = true
        self.isTimelineHidden = true
        self.userDates.isHidden = true
        self.photosHeight.constant = 192
    }
    
    //MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.subcontentView.layer.cornerRadius = 2
        self.subcontentView.layer.shadowColor = UIColor(red: 0, green: 0, blue: 1/255.0, alpha: 1).cgColor
        self.subcontentView.layer.shadowOffset = CGSize(width: 0, height: 1.5);
        self.subcontentView.layer.shadowOpacity = 0.15
        self.subcontentView.layer.shadowRadius = 5
    }
    
    // Manipulate data
    func populateView() {
        
        let photo = Picture()
        let strUrl = "https://upload.wikimedia.org/wikipedia/commons/2/21/EverestfromKalarPatarcrop.JPG"
        photo.url = URL(string: strUrl)
        
        let photo1 = Picture()
        if(self.data != nil){
            
            if( self.data?.id != "" && self.data!.secret != ""){
                let flickrUrl = "https://farm8.staticflickr.com/7564/\(self.data!.id)_\(self.data!.secret)_m.jpg"
                photo1.url = URL(string: flickrUrl)
                self.photosView.data = [photo1,photo]
            }
            
        }
        
        self.likedButton.setBackgroundImage(self.data?.isfamily != 0 ? #imageLiteral(resourceName: "liked"): #imageLiteral(resourceName: "unLike"), for: UIControlState.normal)
        self.saved.setBackgroundImage(self.data?.ispublic != 0 ? #imageLiteral(resourceName: "saved") : #imageLiteral(resourceName: "unSave"), for: .normal)
        
        self.name.text = self.data?.title
        self.userName.text = "Username"
        self.sum.text = "90 USD"
        self.likes.text = "6"
        self.views.text = "8"
        self.day.text = "9 days"
        
        let url = "https://upload.wikimedia.org/wikipedia/commons/2/21/EverestfromKalarPatarcrop.JPG"
        self.userImage.loadFromUrl(url: url , noImage: #imageLiteral(resourceName: "bgNoImage"))
    }
    
    //MARK: Action
    var likeTripAction:((_ model: ListPhotoItem)->())?
    @IBAction func buttonLikeTouchInside(_ sender: Any){
        print("Show")
        self.likeTripAction?(self.data!)
    }
    
    var viewAction:((_ model: ListPhotoItem)->())?
    @IBAction func buttonViewTouchInside(_ sender: Any){
        print("Show")
    
    }
    
    var savedTripAction:((_ model: ListPhotoItem)->())?
    @IBAction func buttonSavedTouchInside(_ sender: Any){
        print("Show")
        self.savedTripAction?(self.data!)
    }
}
