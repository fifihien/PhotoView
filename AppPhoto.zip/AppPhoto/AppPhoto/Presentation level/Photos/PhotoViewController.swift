//
//  ViewController.swift
//  AppPhoto
//
//  Created by Hien on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON
import RxSwift


class PhotoViewController: UIViewController, UITableViewDelegate,
UITableViewDataSource {
    
    //MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: - Properties
    var photo:PhotoModel! //Array of dictionary
    var disposableBag = DisposeBag()
    var currentLeftSafeAreaInset  : CGFloat = 0.0
    var currentRightSafeAreaInset : CGFloat = 0.0
    var selectedIndexPath: IndexPath!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Hide tabbar
        self.tabBarController?.tabBar.isHidden = true
        self.tabBarController?.tabBar.layer.zPosition = -1
        
        // Do any additional setup after loading the view, typically from a nib.
        self.tableView.register(UINib(nibName: "\(PhotoTableCell.self)", bundle: nil), forCellReuseIdentifier: "\(PhotoTableCell.self)")
        
        // Init photo
        self.photo = PhotoModel(page: 0, pages: 0, perPage: 0, photos: [ListPhotoItem](), total: 0)
        
        // Fetch data default at page 0 and 5 items per page
        self.fetchDate(pageIndex: 0, pageSize: 5)
        
        
       
    }
    
    override func viewSafeAreaInsetsDidChange() {
        
        //if the application launches in landscape mode, the safeAreaInsets
        //need to be updated from 0.0 if the device is an iPhone X model. At
        //application launch this function is called before viewWillLayoutSubviews()
        if #available(iOS 11, *) {
            
            self.currentLeftSafeAreaInset = self.view.safeAreaInsets.left
            self.currentRightSafeAreaInset = self.view.safeAreaInsets.right
        }
        
    }
    
    override func viewWillLayoutSubviews() {
        
        //Only perform these changes for devices running iOS 11 and later. This is called
        //inside viewWillLayoutSubviews() instead of viewWillTransition() because when the
        //device rotates, the navBarHeight and statusBarHeight will be calculated inside
        //viewWillTransition() using the current orientation, and not the orientation
        //that the device will be at the end of the transition.
        
        //By the time that viewWillLayoutSubviews() is called, the views frames have been
        //properly updated for the new orientation, so the navBar and statusBar height values
        //can be calculated and applied directly as per the code below
        
        if #available(iOS 11, *) {
            
            self.view.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: self.view.bounds.size)
            self.tableView.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: self.view.bounds.size)
            
            self.tableView.contentInsetAdjustmentBehavior = .never
            let statusBarHeight : CGFloat = UIApplication.shared.statusBarFrame.height
            let navBarHeight : CGFloat = navigationController?.navigationBar.frame.height ?? 0
            self.edgesForExtendedLayout = .all
            let tabBarHeight = self.tabBarController?.tabBar.frame.height ?? 0
            
            if UIDevice.current.orientation.isLandscape {
                self.tableView.contentInset = UIEdgeInsets(top: (navBarHeight) + statusBarHeight, left: self.currentLeftSafeAreaInset, bottom: tabBarHeight, right: self.currentRightSafeAreaInset)
            }
            else {
                self.tableView.contentInset = UIEdgeInsets(top: (navBarHeight) + statusBarHeight, left: 0.0, bottom: tabBarHeight, right: 0.0)
            }
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        if #available(iOS 11, *) {
            //Do nothing
        }
        else {
            
            //Support for devices running iOS 10 and below
            
            //Check to see if the view is currently visible, and if so,
            //animate the frame transition to the new orientation
            if self.viewIfLoaded?.window != nil {
                
                coordinator.animate(alongsideTransition: { _ in
                    
                    //This needs to be called inside viewWillTransition() instead of viewWillLayoutSubviews()
                    //for devices running iOS 10.0 and earlier otherwise the frames for the view and the
                    //tableView will not be calculated properly.
                    self.view.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: size)
                    self.tableView.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: size)
                    
                }, completion: { _ in
                    
                    //Invalidate the tableView
                    self.tableView.invalidateIntrinsicContentSize()
                    
                })
                
            }
                //Otherwise, do not animate the transition
            else {
                
                self.view.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: size)
                self.tableView.frame = CGRect(origin: CGPoint(x: 0, y: 0), size: size)
                
                //Invalidate the tableView
                self.tableView.invalidateIntrinsicContentSize()
            
            }
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowPhotoPageView" {
            let nav = self.navigationController
            let vc = segue.destination as! PhotoPageContainerViewController
            nav?.delegate = vc.transitionController
            vc.transitionController.fromDelegate = self
            vc.transitionController.toDelegate = vc
            vc.delegate = self
            vc.currentIndex = self.selectedIndexPath.row
            vc.photos = self.photo.photos
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //This function prevents the tableView from accessing a deallocated cell. In the event
    //that the cell for the selectedIndexPath is nil, a default UIImageView is returned in its place
    func getImageViewFromCollectionViewCell(for selectedIndexPath: IndexPath) -> UIImageView {
        
        //Get the array of visible cells in the tableView
        let visibleCells = self.tableView.indexPathForSelectedRow //indexPathsForVisibleItems
        
        //If the current indexPath is not visible in the tableView,
        //scroll the tableView to the cell to prevent it from returning a nil value
        if visibleCells!.contains(self.selectedIndexPath.row) {
            
            //Scroll the tableView to the current selectedIndexPath which is offscreen
            self.tableView.scrollToRow(at: self.selectedIndexPath, at: .middle, animated: false)
            
            //Reload the items at the newly visible indexPaths
            self.tableView.reloadRows(at: self.tableView.indexPathsForVisibleRows!, with: .automatic)
            self.tableView.layoutIfNeeded()
            
            //Guard against nil values
            guard let guardedCell = (self.tableView.cellForRow(at: self.selectedIndexPath) as? PhotoTableCell) else {
                //Return a default UIImageView
                return UIImageView(frame: CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 100.0, height: 100.0))
            }
            //The PhotoViewCell was found in the tableView, return the image
            return guardedCell.userImage
        }
        else {
            
            //Guard against nil return values
            guard let guardedCell = self.tableView.cellForRow(at: self.selectedIndexPath) as? PhotoTableCell else {
                //Return a default UIImageView
                return UIImageView(frame: CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 100.0, height: 100.0))
            }
            //The PhotoViewCell was found in the tableView, return the image
            return guardedCell.userImage!
        }
        
    }
    
    //This function prevents the tableView from accessing a deallocated cell. In the
    //event that the cell for the selectedIndexPath is nil, a default CGRect is returned in its place
    func getFrameFromCollectionViewCell(for selectedIndexPath: IndexPath) -> CGRect {
        
        //Get the currently visible cells from the tableView
        let visibleCells = self.tableView.indexPathsForVisibleRows
        
        //If the current indexPath is not visible in the tableView,
        //scroll the tableView to the cell to prevent it from returning a nil value
        if (visibleCells?.contains(self.selectedIndexPath))! {
            
            //Scroll the tableView to the cell that is currently offscreen
            self.tableView.scrollToRow(at: self.selectedIndexPath, at: .middle, animated: false)
            
            //Reload the items at the newly visible indexPaths
            self.tableView.reloadRows(at: self.tableView.indexPathsForVisibleRows!, with: .automatic)
            self.tableView.layoutIfNeeded()
            
            //Prevent the tableView from returning a nil value
            guard let guardedCell = (self.tableView.cellForRow(at: self.selectedIndexPath) as? PhotoTableCell) else {
                return CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 100.0, height: 100.0)
            }
            
            return guardedCell.frame
        }
            //Otherwise the cell should be visible
        else {
            //Prevent the tableView from returning a nil value
            guard let guardedCell = (self.tableView.cellForRow(at: self.selectedIndexPath) as? PhotoTableCell) else {
                return CGRect(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY, width: 100.0, height: 100.0)
            }
            //The cell was found successfully
            return guardedCell.frame
        }
    }
    
}

extension PhotoViewController {
    
    // Fect data from api Flickr
    func fetchDate(pageIndex: Int, pageSize: Int){
        
        PhotoListUseCase(pageIndex: pageIndex, cursor: "nextCursor",
                         pageSize:pageSize )
            .execute()
            .subscribe(onNext: { [weak self] (responseInfo) in
                
                self?.photo.updatePhoto(photo: responseInfo)
                self?.tableView.reloadData()
                
                }, onError: { (error) in
                    print(error)
            }, onCompleted: {
                
            }).disposed(by: self.disposableBag)
        
    }
}

extension PhotoViewController {
    
    //MARK: - Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard self.photo != nil else{
            return 0
        }
        return (self.photo?.photos.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(PhotoTableCell.self)") as! PhotoTableCell
        cell.setHomeMode()
        cell.data = self.photo.photos[indexPath.row]
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        let lastElement = self.photo.photos.count - 1
        if indexPath.row == lastElement && self.photo.photos.count < self.photo.total! {
            self.fetchDate(pageIndex: self.photo.page, pageSize: self.photo.perpage)
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        self.selectedIndexPath = indexPath
        self.performSegue(withIdentifier: "ShowPhotoPageView", sender: self)
        
    }
    
}

extension PhotoViewController: PhotoPageContainerViewControllerDelegate {
    
    func containerViewController(_ containerViewController: PhotoPageContainerViewController, indexDidUpdate currentIndex: Int) {
        self.selectedIndexPath = IndexPath(row: currentIndex, section: 0)
        self.tableView.scrollToRow(at: self.selectedIndexPath, at: .middle, animated: false)
    }
}

extension PhotoViewController: ZoomAnimatorDelegate {
    
    func transitionWillStartWith(zoomAnimator: ZoomAnimator) {
        
    }
    
    func transitionDidEndWith(zoomAnimator: ZoomAnimator) {
        let cell = self.tableView.cellForRow(at: self.selectedIndexPath) as! PhotoTableCell

        let cellFrame = self.tableView.convert(cell.frame, to: self.view)

        if cellFrame.minY < self.tableView.contentInset.top {
            self.tableView.scrollToRow(at: self.selectedIndexPath, at: .top, animated: false)
        } else if cellFrame.maxY > self.view.frame.height - self.tableView.contentInset.bottom {
            self.tableView.scrollToRow(at: self.selectedIndexPath, at: .bottom, animated: false)
        }
    }
    
    func referenceImageView(for zoomAnimator: ZoomAnimator) -> UIImageView? {
        
        //Get a guarded reference to the cell's UIImageView
//        let referenceImageView = getImageViewFromCollectionViewCell(for: self.selectedIndexPath)
        let referenceImageView = UIImageView()
        return referenceImageView
    }
    
    func referenceImageViewFrameInTransitioningView(for zoomAnimator: ZoomAnimator) -> CGRect? {
        
        self.view.layoutIfNeeded()
        self.tableView.layoutIfNeeded()
        //Get a guarded reference to the cell's frame
        let unconvertedFrame = getFrameFromCollectionViewCell(for: self.selectedIndexPath)
        
        let cellFrame = self.tableView.convert(unconvertedFrame, to: self.view)
        
        if cellFrame.minY < self.tableView.contentInset.top {
            return CGRect(x: cellFrame.minX, y: self.tableView.contentInset.top, width: cellFrame.width, height: cellFrame.height - (self.tableView.contentInset.top - cellFrame.minY))
        }
        
        return cellFrame
    }
    
}


