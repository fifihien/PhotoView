//
//  UserSessionManagerImp.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

class UserSessionManagerImp: UserSessionManager {
    
    private var sessionStorage: SessionStorage
    private var sessionObservers = [UserSessionObserver]()
    
    init(sessionStorage: SessionStorage) {
        self.sessionStorage = sessionStorage
    }
    
    var isAuthorized: Bool {
        return currentSession.accessToken != nil
    }
    
    private var _currentSession: Session?
    var currentSession: Session {
        get {
            if let session = _currentSession {
                return session
            } else {
                _currentSession = sessionStorage.userSession
                return _currentSession!
            }
        } set {
            sessionStorage.userSession = newValue
            _currentSession = newValue
            self.notifyObservers(with: newValue)
        }
    }
    
    func clearSession() {
        var session = self.currentSession
        session.accessToken = nil
        session.accessTokenExpire = nil
        session.refreshToken = nil
        session.userId = nil
        currentSession = session
    }
    
    func addSessionObserver(observer: UserSessionObserver) {
        for obs in sessionObservers {
            if obs.id == observer.id {
                return
            }
        }
        sessionObservers.append(observer)
    }
    
    func removeSessionObserver(observer: UserSessionObserver) {
        sessionObservers = sessionObservers.filter{ $0.id != observer.id }
    }
    
    //MARK: Private
    
    private func notifyObservers(with session: Session) {
        for observer in sessionObservers {
            observer.sessionDidUpdate(session: session)
        }
    }
}
