//
//  UserSessionManager.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

protocol UserSessionManager {
    
    var isAuthorized: Bool {get}
    
    var currentSession: Session {get set}
    
    func clearSession()
    
    func addSessionObserver(observer: UserSessionObserver)
    
    func removeSessionObserver(observer: UserSessionObserver)
}

protocol UserSessionObserver {
    
    var id : Int{ get }
    func sessionDidUpdate(session: Session)
    
}
