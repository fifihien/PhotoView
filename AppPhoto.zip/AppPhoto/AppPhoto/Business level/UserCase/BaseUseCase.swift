//
//  BaseUseCase.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import RxSwift

class BaseUseCase<T> {
    
    func makeUseCaseObservable() -> Observable<T> {
        return Observable.empty()
    }
    
    func execute() -> Observable<T> {
        
        let retrySequence = self.makeUseCaseObservable()
        return retrySequence.retryWhen({ (observableError) -> Observable<T> in
            
            let internalSequence = observableError.flatMap({ (error) -> Observable<T> in
                
                return Observable.error(error)
            })
            return internalSequence
        })
    }
    
}

