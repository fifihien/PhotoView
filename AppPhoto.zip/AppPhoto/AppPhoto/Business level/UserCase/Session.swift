//
//  Session.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//
import Foundation

protocol BaseModel {
    
}

struct Session : BaseModel {
    
    var accessToken: String?
    var refreshToken: String?
    var accessTokenExpire: Date?
    var userId: String?
    
}
