//
//  PhotoListUserCase.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
import RxSwift


class PhotoListUseCase: BaseUseCase<PhotoModel> {
    
    var pageIndex: Int
    var cursor: String
    var pageSize: Int
    var networkDispatcher: NetworkDispatcher
    
    init(pageIndex: Int, cursor: String, pageSize: Int) {
        self.pageIndex = pageIndex
        self.cursor = cursor
        self.pageSize = pageSize
        self.networkDispatcher = ApplicationFactoryImp.sharedFactory.makeNetworkServiceFactory().makeMainNetworkDispatcher()
        
    }
    
    var requestOperaton: PhotoListOperations {
        return PhotoListOperations(pageIndex: self.pageIndex, cursor: self.cursor, pageSize: self.pageSize)
    }
    
    
    override func makeUseCaseObservable() -> Observable<PhotoModel> {
        return self.requestOperaton.execute(in: self.networkDispatcher)
            .map({ (response) -> PhotoModel in
                
                let photo = (response.data?.photo ?? []).map { ListPhotoItem.makePhoto(withDTO: $0) }
                let photoModel = PhotoModel(page: (response.data?.page)!, pages: (response.data?.pages)!, perPage: (response.data?.perpage)!, photos: photo, total: (response.data?.total)!)
                return photoModel
                
            })
    }
    
}
