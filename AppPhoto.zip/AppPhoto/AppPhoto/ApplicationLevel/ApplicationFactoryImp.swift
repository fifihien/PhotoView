//
//  ApplicationFactoryImp.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

private let _sharedFactory = ApplicationFactoryImp()

class ApplicationFactoryImp: ApplicationFactory {
    
    func makeNetworkServiceFactory() -> NetworkServiceFactory {
        return NetworkServiceFactoryImp()
    }
    
    class var sharedFactory: ApplicationFactory {
        return _sharedFactory
    }
    
    var _sessionManager: UserSessionManagerImp?
    func makeSessionManager() -> UserSessionManager {
        if _sessionManager == nil {
            _sessionManager = UserSessionManagerImp(sessionStorage: UserDefaultsStorageImp())
        }
        return _sessionManager!
    }
    
}
