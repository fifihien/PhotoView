//
//  Photo.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

struct PhotoModel{
    
    var page : Int
    var pages : Int
    var perpage : Int
    var photos: [ListPhotoItem]
    var total : Int?
    init() {
        self.page = 0
        self.pages = 0
        self.perpage = 0
        self.total = 0
        self.photos = [ListPhotoItem]()
    }
    
    init(page: Int, pages: Int, perPage: Int, photos: [ListPhotoItem],total: Int) {
        self.page = page
        self.pages = pages
        self.perpage = perPage
        self.total = total
        self.photos = photos
    }
    mutating func updatePhoto(photo:PhotoModel) {
        
        self.page = self.page + 1
        self.pages = photo.pages
        self.perpage = photo.perpage
        self.total = photo.total
        for item in photo.photos {
            self.photos.append(item)
        }
    }
    
}

extension PhotoModel {
    static func makePhotoModel(with page: Int, pages:Int, perpage: Int, photos: [ListPhotoItem], total: Int) -> PhotoModel{
        return PhotoModel(page: page, pages: pages, perPage: perpage, photos: photos, total: total)
    }
}

struct ListPhotoItem {
    var farm : Int = 0
    var id : String = ""
    var isfamily : Int = 0
    var isfriend : Int = 0
    var ispublic : Int = 0
    var owner : String = ""
    var secret : String = ""
    var server : String = ""
    var title : String = ""
    
    func getUrl()-> String{
        if( self.id != "" && self.secret != ""){
            let flickrUrl = "https://farm8.staticflickr.com/7564/\(self.id)_\(self.secret)_c.jpg"
            return flickrUrl
        }
        
        return ""
    }
}


extension ListPhotoItem {
    static func makePhoto(withDTO photoDTO: ListPhotoItemDTO) -> ListPhotoItem {
        return ListPhotoItem(
            farm: photoDTO.farm ?? 0,
            id: photoDTO.id ?? "",
            isfamily: photoDTO.isfamily ?? 0,
            isfriend: photoDTO.isfriend ?? 0,
            ispublic: photoDTO.ispublic ?? 0,
            owner: photoDTO.owner ?? "",
            secret: photoDTO.secret ?? "",
            server: photoDTO.server ?? "",
            title: photoDTO.title ?? ""
        )
    }
}
