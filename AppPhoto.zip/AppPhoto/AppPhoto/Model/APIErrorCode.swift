//
//  APIErrorCode.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation

enum APIErrorCode: String {
    
    case refreshTokenInvalid = "sec.refresh_token_invalid"
    case accessTokenInvalid = "sec.access_token_invalid"
    
    /*
     common.field_not_blank    Поле не может быть пустым
     common.field_size_max
     Поле слишком длинное
     common.field_size_min
     Поле слишком короткое
     common.field_invalid_length    Поле иммет некорректную длину
     common.field_not_valid_chars    Поле содержит невалидные символы
     common.field_max    Число не может быть больше N
     common.field_min    Число не может быть меньше N
     common.field_future    Дата должна быть позже N
     common.field_past    Дата должна быть раньше N
     common.field_email    Email не валиден
     common.field_card_number    Номер карты не валиден
     common.field_phone    Номер телефона не валиден
     common.field_duplicate    Значение у поля должно быть уникально
     */
    
    case unknown = "Unknown"
    case invalidAuthData = "sec.invalid_auth_data"
    case loginShouldBeConfirmed = "sec.login_should_be_confirmed"
    
    
    case PassCodeNotValid = "sec.pass_code_not_valid"
    
    case UnprocessableEntity = "unprocessable_entity"
    case BadParameters = "bad_parameters"
    case InternalError = "internal_error"
    case NotFound = "not_found"
    case SecurityError = "security_error"
    case PermissionError = "permission_error"
    
    case FieldNotBlank = "common.field_not_blank"
    case FieldSizeMax = "common.field_size_max"
    case FieldSizeMin = "common.field_size_min"
    case FieldInvalidLength = "common.field_invalid_length"
    case FieldNotValidChars = "common.field_not_valid_chars"
    case FieldNumberMax = "common.field_max"
    case FieldNumberMin = "common.field_min"
    case FieldFuture = "common.field_future"
    case FieldPast = "common.field_past"
    case EmailNotValid = "common.field_email"
    case CardNumberNotValid = "common.field_card_number"
    case PhoneNumberNotValid = "common.field_phone"
    case FieldDuplicate = "common.field_duplicate"
    
    
}
