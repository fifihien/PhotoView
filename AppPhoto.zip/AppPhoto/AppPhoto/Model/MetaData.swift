//
//  MetaData.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import Foundation
struct MetaData {
    var nextCursor: Int?
    var prevCursor: Int?
}


extension MetaData {
    static func makeMetaData(with nextCursor: Int, prevCursor: Int) -> MetaData {
        return MetaData(
            nextCursor: nextCursor,
            prevCursor: prevCursor
        )
    }
    
    static func getPageSizeDefault()-> String {
        return "10"
    }
}
