//
//  BaseModel.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//
import Foundation

import ObjectMapper


enum GlobalResponseCode: String {
    case success = "ok"
    case businessConflict = "business_conflict"
    case unprocessableEntity = "unprocessable_entity"
    case badParameters = "bad_parameters"
    case internalError = "internal_error"
    case notFound = "not_found"
    case securityError = "security_error"
    case permissionError = "permission_error"
    
    
}

extension GlobalResponseCode {
    
    public var isSuccess: Bool {
        if case .success = self { return true }
        return false
    }
    
    public var isSecurityError: Bool {
        if case .securityError = self { return true }
        return false
    }
}

class BaseResponse: Mappable {
    
    var code: GlobalResponseCode?
    var message: String?
    var errors: [RestError]?
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        code <- (map["stat"] ,EnumTransform<GlobalResponseCode>())
        message <- map["stat"]
        errors <- map["errors"]
    }
    
}

class RestError: Mappable {
    
    var code: APIErrorCode?
    var message: String?
    var field: String?
    
    init(code: APIErrorCode? = .unknown, message: String? = nil, field: String? = nil) {
        self.code = code
        self.message = message
        self.field = field
    }
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        code <- (map["code"], EnumTransform<APIErrorCode>())
        message <- map["message"]
        field <- map["field"]
    }
}


class ObjectResponse<T: Mappable>: BaseResponse {
    
    var data: T?
    var status: String?
    override func mapping(map: Map) {
        super.mapping(map: map)
        data <- map["photos"]
        status <- map["stat"]
    }
}

class ListResponse<T: Mappable>: BaseResponse {
    
    var data: [T]?
    
    var nextCursor: String?
    var prevCursor: String?
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        data <- map["data.items"]
        //data <- map["data"]
        nextCursor <- map["data.nextCursor"]
        prevCursor <- map["data.prevCursor"]
    }
}

class ListCityResponse<T: Mappable>: BaseResponse {
    
    var data: [T]?
    
    var nextCursor: String?
    var prevCursor: String?
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        data <- map["data"]
        nextCursor <- map["data.nextCursor"]
        prevCursor <- map["data.prevCursor"]
    }
}

class ArrayResponse<T: Mappable>: BaseResponse {
    
    var data: [T]?
    
    override func mapping(map: Map) {
        super.mapping(map: map)
        data <- map["data"]
    }
}

