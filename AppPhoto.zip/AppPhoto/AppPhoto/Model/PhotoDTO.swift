//
//  PhotoDTO.swift
//  AppPhoto
//
//  Created by Haley on 6/20/19.
//  Copyright © 2019 Hien Tran. All rights reserved.
//

import ObjectMapper


class PhotoDTO: Mappable {

    var page : Int
    var pages : Int
    var perpage : Int
    var photo : [ListPhotoItemDTO]!
    var total : Int
    
    
    required init?(map: Map) {
        self.page = 0
        self.pages = 0
        self.perpage = 0
        self.total = 0
        self.photo = []
    }
    
    
    func mapping(map: Map) {
        page <- map["page"]
        pages <- map["pages"]
        perpage <- map["perpage"]
        photo <- map["photo"]
        total <- map["total"]
    }
}


class ListPhotoItemDTO: Mappable {
    
    var farm : Int?
    var id : String?
    var isfamily : Int?
    var isfriend : Int?
    var ispublic : Int?
    var owner : String?
    var secret : String?
    var server : String?
    var title : String?
    
    required init?(map: Map) {
        
    }
    
    func mapping(map: Map) {
        farm <- map["farm"]
        id <- map["id"]
        isfamily <- map["isfamily"]
        isfriend <- map["isfriend"]
        ispublic <- map["ispublic"]
        owner <- map["owner"]
        secret <- map["secret"]
        server <- map["server"]
        title <- map["title"]
    }
}
